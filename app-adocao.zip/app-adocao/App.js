import React from 'react';
import { View, StyleSheet, Image } from 'react-native';
import { TextInput, Button, Text, Provider as PaperProvider } from 'react-native-paper';
import AsyncStorage from '@react-native-async-storage/async-storage';

const App = () => {
  const [username, setUsername] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [errorMessage, setErrorMessage] = React.useState('');
  const [isLoggedIn, setIsLoggedIn] = React.useState(false);

  React.useEffect(() => {
    checkSession();
  }, []);

  const checkSession = async () => {
    try {
      const savedUsername = await AsyncStorage.getItem('username');
      if (savedUsername) {
        setUsername(savedUsername);
        setIsLoggedIn(true);
      }
    } catch (error) {
      setErrorMessage('Error: ' + error);
    }
  };

  const handleLogin = async () => {
    if (username === 'admin' && password === 'admin') {
      try {
        await AsyncStorage.setItem('username', username);
        setIsLoggedIn(true);
        setErrorMessage('');
      } catch (error) {
        setErrorMessage(`Failed to save session: ${error.message}`);
      }
    } else {
      setErrorMessage('Incorrect username or password. Please try again.');
    }
  };

  const handleLogout = async () => {
    try {
      await AsyncStorage.removeItem('username');
      setIsLoggedIn(false);
    } catch (error) {
      setErrorMessage('Error: ' + error);
    }
  };

  return (
    <PaperProvider>
      <View style={styles.container}>
        <Image source={require('assets/logocachorro.png')} style={styles.logo} />
        {isLoggedIn ? (
          <View style={styles.loggedInContainer}>
            <Text>Welcome, {username}!</Text>
            <Button icon="logout" mode="contained" onPress={handleLogout} style={styles.button}>
              Logout
            </Button>
          </View>
        ) : (
          <View style={styles.loginContainer}>
            <TextInput
              label="Username"
              value={username}
              onChangeText={setUsername}
              style={styles.input}
            />
            <TextInput
              label="Password"
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              style={styles.input}
            />
            <Button icon="login" mode="contained" onPress={handleLogin} style={styles.button}>
              Login
            </Button>
            {errorMessage ? <Text style={styles.errorText}>{errorMessage}</Text> : null}
          </View>
        )}
      </View>
    </PaperProvider>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  logo: {
    width: 100,  // Adjust these values as needed
    height: 100, // Adjust these values as needed
    marginBottom: 20,
  },
  loginContainer: {
    width: '80%', // Make the login container smaller
    maxWidth: 300, // Add a maximum width to prevent it from being too wide
    padding: 20,
    backgroundColor: 'white', // Optional: Add a background color for better visibility
    borderRadius: 10,
    alignItems: 'center', // Center content inside the container
  },
  input: {
    marginBottom: 10,
    width: '100%', // Make inputs take full width of the container
    backgroundColor: '#F5F5DC', // Set input background color to beige
    borderWidth: 2, // Set the border width
    borderColor: 'green', // Sblacket the border color to dark gray
    height: 40, // Adjust height as needed
  },
  button: {
    marginTop: 10,
    width: '100%', // Make the button take full width of the container
    backgroundColor: 'green', // Set button background color to green
    height: 35, // Adjust height as needed
  },
  loggedInContainer: {
    alignItems: 'center',
  },
  errorText: {
    color: 'red',
    marginTop: 10,
  },
});

export default App;
